"""
Assignment #04 - Question 2 (Deliverables 6, 7):
Hardware-Aware Bayesian Neural Architecture Search (Optuna) on CIFAR-10.
Student: Inamul Haq | Roll No: i22-1906
"""

import os
import sys
import json
import pandas as pd
import optuna
import torch
import torch.nn as nn
import torch.optim as optim

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import DEVICE, Q2_CONFIG, RESULTS_DIR
from utils import set_seed, get_cifar10_loaders, evaluate_accuracy, count_parameters
from q2_nas.search_space import sample_architecture_from_trial, build_architecture_from_config
from q2_nas.hardware_profiler import profile_model_on_cpu, check_deployment_constraints


def run_nas():
    set_seed(42)
    print("=" * 75)
    print("Hardware-Aware Neural Architecture Search (Optuna Bayesian Optimization)")
    print(f"Dataset: CIFAR-10 | Trials: {Q2_CONFIG['n_trials']} | Device: {DEVICE}")
    print(
        f"Constraints -> Max Latency: {Q2_CONFIG['max_latency_ms']} ms | "
        f"Max Size: {Q2_CONFIG['max_model_size_mb']} MB | "
        f"Max Peak RAM: {Q2_CONFIG['max_peak_ram_mb']} MB"
    )
    print("=" * 75)

    train_loader, val_loader = get_cifar10_loaders(
        batch_size=Q2_CONFIG["batch_size"],
        num_workers=Q2_CONFIG["num_workers"],
        subset_ratio=0.5,
    )

    search_history = []
    best_record = {"score": -1e9, "arch_config": None, "metrics": None}

    def objective(trial: optuna.Trial) -> float:
        arch_config = sample_architecture_from_trial(trial)
        model = build_architecture_from_config(arch_config, num_classes=Q2_CONFIG["num_classes"])
        params = count_parameters(model)

        hw_metrics = profile_model_on_cpu(model, input_shape=(1, 3, 32, 32))
        is_valid, reason = check_deployment_constraints(hw_metrics, Q2_CONFIG)

        if not is_valid:
            print(
                f"[Trial {trial.number:02d}] REJECTED ({reason}) | "
                f"Params: {params:,} | Res: {arch_config['input_resolution']}x{arch_config['input_resolution']}"
            )
            search_history.append({
                "trial": trial.number,
                "status": "REJECTED",
                "reason": reason,
                "val_acc_pct": 0.0,
                "latency_ms": hw_metrics["latency_ms"],
                "model_size_mb": hw_metrics["model_size_mb"],
                "peak_ram_mb": hw_metrics["peak_ram_mb"],
                "parameters": params,
                "input_resolution": arch_config["input_resolution"],
                "depth": arch_config["depth"],
                "activation": arch_config["activation"],
                "reward_score": -100.0,
            })
            return -100.0

        model = model.to(DEVICE)
        criterion = nn.CrossEntropyLoss()
        optimizer = optim.AdamW(model.parameters(), lr=2e-3, weight_decay=1e-4)
        scheduler = optim.lr_scheduler.CosineAnnealingLR(
            optimizer, T_max=Q2_CONFIG["proxy_epochs"]
        )

        for _ in range(Q2_CONFIG["proxy_epochs"]):
            model.train()
            for images, labels in train_loader:
                images, labels = images.to(DEVICE), labels.to(DEVICE)
                optimizer.zero_grad()
                loss = criterion(model(images), labels)
                loss.backward()
                optimizer.step()
            scheduler.step()

        val_acc = evaluate_accuracy(model, val_loader, DEVICE)

        latency_penalty = 0.25 * (hw_metrics["latency_ms"] / Q2_CONFIG["max_latency_ms"]) * 10.0
        size_penalty = 0.15 * (hw_metrics["model_size_mb"] / Q2_CONFIG["max_model_size_mb"]) * 10.0
        reward_score = val_acc - latency_penalty - size_penalty

        print(
            f"[Trial {trial.number:02d}] ACCEPTED | Val Acc: {val_acc:5.2f}% | "
            f"Latency: {hw_metrics['latency_ms']:5.2f} ms | "
            f"Size: {hw_metrics['model_size_mb']:4.2f} MB | "
            f"Peak RAM: {hw_metrics['peak_ram_mb']:5.2f} MB | Score: {reward_score:5.2f}"
        )

        search_history.append({
            "trial": trial.number,
            "status": "ACCEPTED",
            "reason": "PASS",
            "val_acc_pct": round(val_acc, 2),
            "latency_ms": hw_metrics["latency_ms"],
            "model_size_mb": hw_metrics["model_size_mb"],
            "peak_ram_mb": hw_metrics["peak_ram_mb"],
            "parameters": params,
            "input_resolution": arch_config["input_resolution"],
            "depth": arch_config["depth"],
            "activation": arch_config["activation"],
            "reward_score": round(reward_score, 4),
        })

        if reward_score > best_record["score"]:
            best_record["score"] = reward_score
            best_record["arch_config"] = arch_config
            best_record["metrics"] = {
                "proxy_val_acc_pct": round(val_acc, 2),
                "parameters": params,
                **hw_metrics,
                "reward_score": round(reward_score, 4),
            }

        return reward_score

    sampler = optuna.samplers.TPESampler(seed=42)
    study = optuna.create_study(direction="maximize", sampler=sampler)
    study.optimize(objective, n_trials=Q2_CONFIG["n_trials"])

    history_csv = os.path.join(RESULTS_DIR, "nas_search_history.csv")
    pd.DataFrame(search_history).to_csv(history_csv, index=False)

    best_json = os.path.join(RESULTS_DIR, "best_nas_architecture.json")
    with open(best_json, "w") as f:
        json.dump(best_record, f, indent=4)

    print("\n" + "=" * 75)
    print("NAS Search Complete!")
    print(f"Best Reward Score: {best_record['score']:.4f}")
    print(f"Best Architecture Config saved -> {best_json}")
    print(f"Full Search History saved      -> {history_csv}")
    print("=" * 75)


if __name__ == "__main__":
    run_nas()
