"""
Assignment #04 - Question 2 (Deliverable 6): Hardware-Aware Profiling & Constraint Verification
Student: Inamul Haq | Roll No: i22-1906
Measures:
  1. Actual CPU inference latency (ms per image)
  2. Serialized model storage footprint (MB)
  3. Peak inference memory usage (MB) via psutil & tracemalloc
  4. Deployment constraint compliance check
"""

import io
import os
import time
import tracemalloc
import psutil
import numpy as np
import torch
import torch.nn as nn


def measure_model_size_mb(model: nn.Module) -> float:
    """Measures exact serialized state_dict size in Megabytes (MB)."""
    buffer = io.BytesIO()
    torch.save(model.state_dict(), buffer)
    size_bytes = buffer.getbuffer().nbytes
    return size_bytes / (1024.0 * 1024.0)


@torch.no_grad()
def profile_model_on_cpu(
    model: nn.Module,
    input_shape=(1, 3, 32, 32),
    warmup_runs: int = 15,
    measure_runs: int = 60,
) -> dict:
    """Profiles CPU latency, model storage size, and peak inference memory."""
    model_cpu = model.to("cpu").eval()
    dummy_input = torch.randn(*input_shape, device="cpu")

    size_mb = measure_model_size_mb(model_cpu)

    for _ in range(warmup_runs):
        _ = model_cpu(dummy_input)

    process = psutil.Process(os.getpid())
    rss_before = process.memory_info().rss / (1024.0 * 1024.0)
    tracemalloc.start()

    latencies_ms = []
    rss_peak = rss_before
    for _ in range(measure_runs):
        t0 = time.perf_counter()
        _ = model_cpu(dummy_input)
        t1 = time.perf_counter()
        latencies_ms.append((t1 - t0) * 1000.0)
        curr_rss = process.memory_info().rss / (1024.0 * 1024.0)
        if curr_rss > rss_peak:
            rss_peak = curr_rss

    _, py_peak_bytes = tracemalloc.get_traced_memory()
    tracemalloc.stop()

    peak_ram_mb = max(rss_peak - rss_before, py_peak_bytes / (1024.0 * 1024.0))
    mean_latency_ms = float(np.mean(latencies_ms))
    p95_latency_ms = float(np.percentile(latencies_ms, 95))

    return {
        "latency_ms": round(mean_latency_ms, 4),
        "p95_latency_ms": round(p95_latency_ms, 4),
        "model_size_mb": round(size_mb, 4),
        "peak_ram_mb": round(peak_ram_mb, 4),
    }


def check_deployment_constraints(metrics: dict, constraints: dict) -> tuple[bool, str]:
    """Checks whether hardware metrics satisfy edge deployment budgets."""
    if metrics["latency_ms"] > constraints["max_latency_ms"]:
        return False, f"Latency {metrics['latency_ms']:.2f}ms > {constraints['max_latency_ms']}ms"
    if metrics["model_size_mb"] > constraints["max_model_size_mb"]:
        return False, f"Size {metrics['model_size_mb']:.2f}MB > {constraints['max_model_size_mb']}MB"
    if metrics["peak_ram_mb"] > constraints["max_peak_ram_mb"]:
        return False, f"Peak RAM {metrics['peak_ram_mb']:.2f}MB > {constraints['max_peak_ram_mb']}MB"
    return True, "PASS"
