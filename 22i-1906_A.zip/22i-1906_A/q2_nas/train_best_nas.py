"""
Assignment #04 - Question 2 (Deliverables 7, 8, 10):
Trains the Best Discovered NAS Architecture from Scratch on CIFAR-10 and Exports to ONNX.
Student: Inamul Haq | Roll No: i22-1906
"""

import os
import sys
import json
import torch
import torch.nn as nn
import torch.optim as optim

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import DEVICE, Q2_CONFIG, CKPT_DIR, ONNX_DIR, RESULTS_DIR
from utils import (
    set_seed,
    get_cifar10_loaders,
    evaluate_accuracy,
    count_parameters,
    export_model_to_onnx,
)
from q2_nas.search_space import build_architecture_from_config


def train_best_discovered_model():
    set_seed(42)
    best_json = os.path.join(RESULTS_DIR, "best_nas_architecture.json")
    if not os.path.exists(best_json):
        raise FileNotFoundError(
            f"Best NAS config not found at {best_json}. Run q2_nas/nas_search.py first!"
        )

    with open(best_json, "r") as f:
        best_record = json.load(f)

    arch_config = best_record["arch_config"]
    model = build_architecture_from_config(
        arch_config, num_classes=Q2_CONFIG["num_classes"]
    ).to(DEVICE)

    print("=" * 75)
    print("Training Best Discovered NAS Architecture from Scratch on CIFAR-10")
    print(f"Parameters: {count_parameters(model):,} | Resolution: {arch_config['input_resolution']}x{arch_config['input_resolution']}")
    print(f"Depth: {arch_config['depth']} | Activation: {arch_config['activation']}")
    print("=" * 75)

    train_loader, test_loader = get_cifar10_loaders(
        batch_size=Q2_CONFIG["batch_size"],
        num_workers=Q2_CONFIG["num_workers"],
        subset_ratio=1.0,
    )

    criterion = nn.CrossEntropyLoss(label_smoothing=0.05)
    optimizer = optim.AdamW(model.parameters(), lr=2e-3, weight_decay=1e-4)
    scheduler = optim.lr_scheduler.CosineAnnealingLR(
        optimizer, T_max=Q2_CONFIG["final_epochs"]
    )

    best_acc = 0.0
    ckpt_path = os.path.join(CKPT_DIR, "best_nas_cifar10.pth")

    for epoch in range(1, Q2_CONFIG["final_epochs"] + 1):
        model.train()
        running_loss = 0.0
        for images, labels in train_loader:
            images, labels = images.to(DEVICE), labels.to(DEVICE)
            optimizer.zero_grad()
            loss = criterion(model(images), labels)
            loss.backward()
            optimizer.step()
            running_loss += loss.item()

        scheduler.step()
        val_acc = evaluate_accuracy(model, test_loader, DEVICE)
        if val_acc >= best_acc:
            best_acc = val_acc
            torch.save(model.state_dict(), ckpt_path)

        print(
            f"[Best NAS] Epoch [{epoch:02d}/{Q2_CONFIG['final_epochs']:02d}] | "
            f"Loss: {running_loss / len(train_loader):.4f} | "
            f"Test Acc: {val_acc:.2f}% | Best: {best_acc:.2f}%"
        )

    best_record["final_test_acc_pct"] = round(best_acc, 2)
    with open(best_json, "w") as f:
        json.dump(best_record, f, indent=4)

    print(f"\n[SAVED] Best NAS checkpoint -> {ckpt_path} (Test Acc: {best_acc:.2f}%)")

    model.load_state_dict(torch.load(ckpt_path, map_location="cpu"))
    onnx_path = os.path.join(ONNX_DIR, "best_nas_model.onnx")
    export_model_to_onnx(model, onnx_path, input_shape=(1, 3, 32, 32))


if __name__ == "__main__":
    train_best_discovered_model()
