"""
Assignment #04 - Question 2 (Deliverable 5): Searchable CNN Space & Architecture Generator
Student: Inamul Haq | Roll No: i22-1906
Search Space Dimensions:
  1. Variable convolutional depth (3 to 6 searchable blocks)
  2. Variable filters/channels per block
  3. Variable kernel sizes (3x3 or 5x5)
  4. Standard Conv vs. Depthwise Separable Conv blocks
  5. Different activation functions (ReLU, ReLU6, Hardswish, SiLU)
  6. Variable input resolutions (24x24, 28x28, 32x32)
"""

import torch
import torch.nn as nn
import torch.nn.functional as F


def get_activation(name: str) -> nn.Module:
    name = name.lower()
    if name == "relu":
        return nn.ReLU(inplace=True)
    elif name == "relu6":
        return nn.ReLU6(inplace=True)
    elif name == "hardswish":
        return nn.Hardswish(inplace=True)
    elif name == "silu":
        return nn.SiLU(inplace=True)
    raise ValueError(f"Unsupported activation: {name}")


class DepthwiseSeparableConv(nn.Module):
    """Edge-friendly Depthwise Separable Convolution block."""

    def __init__(self, in_c: int, out_c: int, kernel_size: int, stride: int, activation: str):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv2d(
                in_c, in_c, kernel_size=kernel_size, stride=stride,
                padding=kernel_size // 2, groups=in_c, bias=False
            ),
            nn.BatchNorm2d(in_c),
            get_activation(activation),
            nn.Conv2d(in_c, out_c, kernel_size=1, bias=False),
            nn.BatchNorm2d(out_c),
            get_activation(activation),
        )

    def forward(self, x):
        return self.net(x)


class StandardConvBlock(nn.Module):
    """Standard Convolution + BatchNorm + Activation block."""

    def __init__(self, in_c: int, out_c: int, kernel_size: int, stride: int, activation: str):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv2d(
                in_c, out_c, kernel_size=kernel_size, stride=stride,
                padding=kernel_size // 2, bias=False
            ),
            nn.BatchNorm2d(out_c),
            get_activation(activation),
        )

    def forward(self, x):
        return self.net(x)


class DynamicEdgeCNN(nn.Module):
    """Dynamically constructed CNN generated from a sampled NAS configuration dictionary."""

    def __init__(self, arch_config: dict, num_classes: int = 10):
        super().__init__()
        self.arch_config = arch_config
        self.input_resolution = arch_config["input_resolution"]
        activation = arch_config["activation"]
        stem_channels = arch_config["stem_channels"]

        self.stem = StandardConvBlock(3, stem_channels, kernel_size=3, stride=1, activation=activation)

        blocks = []
        in_c = stem_channels
        for idx, layer_cfg in enumerate(arch_config["layers"]):
            out_c = layer_cfg["channels"]
            k = layer_cfg["kernel_size"]
            block_type = layer_cfg["block_type"]
            stride = 2 if idx in (1, 3) else 1

            if block_type == "dw_sep":
                blocks.append(DepthwiseSeparableConv(in_c, out_c, k, stride, activation))
            else:
                blocks.append(StandardConvBlock(in_c, out_c, k, stride, activation))
            in_c = out_c

        self.features = nn.Sequential(*blocks)
        self.classifier = nn.Sequential(
            nn.AdaptiveAvgPool2d((1, 1)),
            nn.Flatten(),
            nn.Dropout(arch_config.get("dropout", 0.15)),
            nn.Linear(in_c, num_classes),
        )

    def forward(self, x):
        if x.shape[-1] != self.input_resolution or x.shape[-2] != self.input_resolution:
            x = F.interpolate(
                x, size=(self.input_resolution, self.input_resolution),
                mode="bilinear", align_corners=False
            )
        x = self.stem(x)
        x = self.features(x)
        return self.classifier(x)


def sample_architecture_from_trial(trial) -> dict:
    """Samples a candidate neural network configuration using an Optuna trial."""
    input_resolution = trial.suggest_categorical("input_resolution", [24, 28, 32])
    stem_channels = trial.suggest_categorical("stem_channels", [16, 24, 32])
    depth = trial.suggest_int("depth", 3, 6)
    activation = trial.suggest_categorical("activation", ["relu", "relu6", "hardswish", "silu"])
    dropout = trial.suggest_float("dropout", 0.05, 0.30, step=0.05)

    layers = []
    for i in range(depth):
        if i < 2:
            c_choices = [24, 32, 48, 64]
        elif i < 4:
            c_choices = [48, 64, 96, 128]
        else:
            c_choices = [96, 128, 160, 192]

        channels = trial.suggest_categorical(f"layer_{i}_channels", c_choices)
        kernel_size = trial.suggest_categorical(f"layer_{i}_kernel", [3, 5])
        block_type = trial.suggest_categorical(f"layer_{i}_type", ["dw_sep", "std_conv"])
        layers.append({
            "channels": channels,
            "kernel_size": kernel_size,
            "block_type": block_type,
        })

    return {
        "input_resolution": input_resolution,
        "stem_channels": stem_channels,
        "depth": depth,
        "activation": activation,
        "dropout": dropout,
        "layers": layers,
    }


def build_architecture_from_config(arch_config: dict, num_classes: int = 10) -> nn.Module:
    """Instantiates a DynamicEdgeCNN from a saved JSON architecture dictionary."""
    return DynamicEdgeCNN(arch_config=arch_config, num_classes=num_classes)
