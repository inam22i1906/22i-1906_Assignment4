"""
Assignment #04 - Question 2 (Deliverables 9, 10):
PyTorch & ONNX Runtime CPU Inference Pipeline for the Discovered NAS Model.
Student: Inamul Haq | Roll No: i22-1906
"""

import os
import sys
import json
import time
import numpy as np
import torch
import onnxruntime as ort

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import Q2_CONFIG, CKPT_DIR, ONNX_DIR, RESULTS_DIR
from utils import get_cifar10_loaders
from q2_nas.search_space import build_architecture_from_config


def run_nas_inference():
    best_json = os.path.join(RESULTS_DIR, "best_nas_architecture.json")
    ckpt_path = os.path.join(CKPT_DIR, "best_nas_cifar10.pth")
    onnx_path = os.path.join(ONNX_DIR, "best_nas_model.onnx")

    with open(best_json, "r") as f:
        arch_config = json.load(f)["arch_config"]

    _, test_loader = get_cifar10_loaders(batch_size=64, num_workers=0)
    images, labels = next(iter(test_loader))
    images_np = images.numpy()
    labels_np = labels.numpy()

    pt_model = build_architecture_from_config(arch_config, Q2_CONFIG["num_classes"]).to("cpu").eval()
    pt_model.load_state_dict(torch.load(ckpt_path, map_location="cpu"))
    with torch.no_grad():
        _ = pt_model(images[:1])
        t0 = time.perf_counter()
        pt_logits = pt_model(images).numpy()
        pt_ms = (time.perf_counter() - t0) * 1000.0 / len(images_np)
    pt_acc = 100.0 * np.mean(np.argmax(pt_logits, axis=1) == labels_np)

    session = ort.InferenceSession(onnx_path, providers=["CPUExecutionProvider"])
    in_name = session.get_inputs()[0].name
    _ = session.run(None, {in_name: images_np[:1]})
    t0 = time.perf_counter()
    ort_logits = session.run(None, {in_name: images_np})[0]
    ort_ms = (time.perf_counter() - t0) * 1000.0 / len(images_np)
    ort_acc = 100.0 * np.mean(np.argmax(ort_logits, axis=1) == labels_np)

    max_diff = float(np.max(np.abs(pt_logits - ort_logits)))

    print("=" * 75)
    print("Best NAS Architecture Inference Verification (CIFAR-10)")
    print("=" * 75)
    print(f"PyTorch CPU      | Batch Acc: {pt_acc:5.2f}% | Latency/Img: {pt_ms:6.3f} ms")
    print(f"ONNX Runtime CPU | Batch Acc: {ort_acc:5.2f}% | Latency/Img: {ort_ms:6.3f} ms")
    print(f"Max Logit Diff (PyTorch vs ONNX): {max_diff:.6e}")


if __name__ == "__main__":
    run_nas_inference()
