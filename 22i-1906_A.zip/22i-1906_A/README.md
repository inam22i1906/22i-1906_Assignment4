# Assignment #04: Edge Computing & Intelligent Systems
- **Name:** Inamul Haq
- **Roll No:** i22-1906

## Setup & Installation
```bash
python -m venv venv
.\venv\Scripts\activate
pip install -r requirements.txt
```

## Step-by-Step Execution Order
1. **Train ResNet-50 Teacher on CIFAR-100:**
   ```bash
   python q1_kd/train_teacher.py
   ```
2. **Train Baseline & Distilled Students (MobileNetV2, SqueezeNet, EfficientNet-Lite0) + Export ONNX:**
   ```bash
   python q1_kd/train_students.py
   ```
3. **Run Unified Student Inference (PyTorch & ONNX Runtime CPU):**
   ```bash
   python q1_kd/inference_kd.py
   ```
4. **Run Hardware-Aware Bayesian NAS on CIFAR-10:**
   ```bash
   python q2_nas/nas_search.py
   ```
5. **Train Best Discovered NAS Architecture from Scratch + Export ONNX:**
   ```bash
   python q2_nas/train_best_nas.py
   ```
6. **Verify NAS Inference (PyTorch & ONNX Runtime CPU):**
   ```bash
   python q2_nas/inference_nas.py
   ```
7. **Run Automated CPU Benchmarking & Generate Technical Report PDF:**
   ```bash
   python benchmark_all.py
   python generate_report.py
   ```
