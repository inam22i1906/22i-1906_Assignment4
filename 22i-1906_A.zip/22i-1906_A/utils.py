"""
Assignment #04 - Shared Utilities
Student: Inamul Haq | Roll No: i22-1906
"""

import os
import random
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, Subset
import torchvision
import torchvision.transforms as transforms
from config import DATA_DIR, FAST_DEMO


def set_seed(seed: int = 42):
    """Set random seeds for reproducibility across runs."""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def get_cifar100_loaders(batch_size: int = 128, num_workers: int = 2):
    """Returns CIFAR-100 train and test DataLoaders with standard data augmentation."""
    mean = (0.5071, 0.4867, 0.4408)
    std = (0.2675, 0.2565, 0.2761)

    train_transform = transforms.Compose([
        transforms.RandomCrop(32, padding=4),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        transforms.Normalize(mean, std),
    ])
    test_transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize(mean, std),
    ])

    train_set = torchvision.datasets.CIFAR100(
        root=DATA_DIR, train=True, download=True, transform=train_transform
    )
    test_set = torchvision.datasets.CIFAR100(
        root=DATA_DIR, train=False, download=True, transform=test_transform
    )

    if FAST_DEMO:
        train_set = Subset(train_set, range(4000))
        test_set = Subset(test_set, range(1000))

    train_loader = DataLoader(
        train_set, batch_size=batch_size, shuffle=True,
        num_workers=num_workers, pin_memory=torch.cuda.is_available()
    )
    test_loader = DataLoader(
        test_set, batch_size=batch_size, shuffle=False,
        num_workers=num_workers, pin_memory=torch.cuda.is_available()
    )
    return train_loader, test_loader


def get_cifar10_loaders(batch_size: int = 128, num_workers: int = 2, subset_ratio: float = 1.0):
    """Returns CIFAR-10 train and test DataLoaders."""
    mean = (0.4914, 0.4822, 0.4465)
    std = (0.2023, 0.1994, 0.2010)

    train_transform = transforms.Compose([
        transforms.RandomCrop(32, padding=4),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        transforms.Normalize(mean, std),
    ])
    test_transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize(mean, std),
    ])

    train_set = torchvision.datasets.CIFAR10(
        root=DATA_DIR, train=True, download=True, transform=train_transform
    )
    test_set = torchvision.datasets.CIFAR10(
        root=DATA_DIR, train=False, download=True, transform=test_transform
    )

    if FAST_DEMO:
        train_set = Subset(train_set, range(4000))
        test_set = Subset(test_set, range(1000))
    elif subset_ratio < 1.0:
        n_train = int(len(train_set) * subset_ratio)
        n_test = int(len(test_set) * subset_ratio)
        train_set = Subset(train_set, range(n_train))
        test_set = Subset(test_set, range(n_test))

    train_loader = DataLoader(
        train_set, batch_size=batch_size, shuffle=True,
        num_workers=num_workers, pin_memory=torch.cuda.is_available()
    )
    test_loader = DataLoader(
        test_set, batch_size=batch_size, shuffle=False,
        num_workers=num_workers, pin_memory=torch.cuda.is_available()
    )
    return train_loader, test_loader


@torch.no_grad()
def evaluate_accuracy(model: nn.Module, loader: DataLoader, device: torch.device) -> float:
    """Computes top-1 classification accuracy (%) on a DataLoader."""
    model.eval()
    correct, total = 0, 0
    for images, labels in loader:
        images, labels = images.to(device), labels.to(device)
        outputs = model(images)
        if isinstance(outputs, tuple):
            outputs = outputs[0]
        preds = outputs.argmax(dim=1)
        correct += (preds == labels).sum().item()
        total += labels.size(0)
    return 100.0 * correct / max(total, 1)


def count_parameters(model: nn.Module) -> int:
    """Returns total trainable parameters."""
    return sum(p.numel() for p in model.parameters() if p.requires_grad)


def export_model_to_onnx(model: nn.Module, onnx_path: str, input_shape=(1, 3, 32, 32)):
    """Exports a PyTorch model to ONNX format on CPU."""
    model_cpu = model.to("cpu").eval()
    dummy_input = torch.randn(*input_shape, device="cpu")
    torch.onnx.export(
        model_cpu,
        dummy_input,
        onnx_path,
        export_params=True,
        opset_version=14,
        do_constant_folding=True,
        input_names=["input"],
        output_names=["logits"],
        dynamic_axes={"input": {0: "batch_size"}, "logits": {0: "batch_size"}},
    )
    print(f"[ONNX] Exported model successfully -> {onnx_path}")
