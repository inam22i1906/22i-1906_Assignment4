"""
Assignment #04 - Deliverable 11: Automated Edge Deployment Benchmarking Script
Student: Inamul Haq | Roll No: i22-1906
Benchmarks all models (Teacher, Distilled Students, NAS Model) on CPU across PyTorch and ONNX Runtime.
"""

import os
import json
import time
import numpy as np
import pandas as pd
import torch
import onnxruntime as ort

from config import Q1_CONFIG, Q2_CONFIG, CKPT_DIR, ONNX_DIR, RESULTS_DIR
from utils import count_parameters
from q1_kd.models import ResNet50Teacher, build_student
from q2_nas.search_space import build_architecture_from_config
from q2_nas.hardware_profiler import profile_model_on_cpu


def benchmark_onnx_cpu(onnx_path: str, runs: int = 80) -> tuple[float, float]:
    """Measures ONNX Runtime CPU latency (ms/img) and file size (MB)."""
    size_mb = os.path.getsize(onnx_path) / (1024.0 * 1024.0)
    sess_opts = ort.SessionOptions()
    sess_opts.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
    session = ort.InferenceSession(
        onnx_path, sess_options=sess_opts, providers=["CPUExecutionProvider"]
    )
    in_name = session.get_inputs()[0].name
    dummy = np.random.randn(1, 3, 32, 32).astype(np.float32)

    for _ in range(15):
        _ = session.run(None, {in_name: dummy})

    times = []
    for _ in range(runs):
        t0 = time.perf_counter()
        _ = session.run(None, {in_name: dummy})
        times.append((time.perf_counter() - t0) * 1000.0)

    return round(float(np.mean(times)), 4), round(size_mb, 4)


def run_benchmarks():
    print("=" * 80)
    print("Running Comprehensive Edge CPU Benchmarks (PyTorch vs ONNX Runtime)")
    print("=" * 80)

    rows = []

    teacher = ResNet50Teacher(num_classes=Q1_CONFIG["num_classes"])
    teacher_ckpt = os.path.join(CKPT_DIR, "teacher_resnet50_cifar100.pth")
    if os.path.exists(teacher_ckpt):
        teacher.load_state_dict(torch.load(teacher_ckpt, map_location="cpu"))
    t_prof = profile_model_on_cpu(teacher)
    rows.append({
        "model": "ResNet50_Teacher (CIFAR-100)",
        "parameters": count_parameters(teacher),
        "pytorch_size_mb": t_prof["model_size_mb"],
        "pytorch_latency_ms": t_prof["latency_ms"],
        "onnx_size_mb": None,
        "onnx_latency_ms": None,
        "onnx_fps": None,
        "peak_ram_mb": t_prof["peak_ram_mb"],
    })

    for s_name in Q1_CONFIG["students"]:
        student = build_student(s_name, num_classes=Q1_CONFIG["num_classes"])
        ckpt = os.path.join(CKPT_DIR, f"distilled_{s_name}_cifar100.pth")
        onnx_p = os.path.join(ONNX_DIR, f"distilled_{s_name}.onnx")
        if os.path.exists(ckpt):
            student.load_state_dict(torch.load(ckpt, map_location="cpu"))

        s_prof = profile_model_on_cpu(student)
        onnx_lat, onnx_sz = (None, None)
        if os.path.exists(onnx_p):
            onnx_lat, onnx_sz = benchmark_onnx_cpu(onnx_p)

        rows.append({
            "model": f"KD_{s_name} (CIFAR-100)",
            "parameters": count_parameters(student),
            "pytorch_size_mb": s_prof["model_size_mb"],
            "pytorch_latency_ms": s_prof["latency_ms"],
            "onnx_size_mb": onnx_sz,
            "onnx_latency_ms": onnx_lat,
            "onnx_fps": round(1000.0 / onnx_lat, 1) if onnx_lat else None,
            "peak_ram_mb": s_prof["peak_ram_mb"],
        })

    best_json = os.path.join(RESULTS_DIR, "best_nas_architecture.json")
    if os.path.exists(best_json):
        with open(best_json, "r") as f:
            arch_cfg = json.load(f)["arch_config"]
        nas_model = build_architecture_from_config(arch_cfg, Q2_CONFIG["num_classes"])
        nas_ckpt = os.path.join(CKPT_DIR, "best_nas_cifar10.pth")
        nas_onnx = os.path.join(ONNX_DIR, "best_nas_model.onnx")
        if os.path.exists(nas_ckpt):
            nas_model.load_state_dict(torch.load(nas_ckpt, map_location="cpu"))

        n_prof = profile_model_on_cpu(nas_model)
        onnx_lat, onnx_sz = (None, None)
        if os.path.exists(nas_onnx):
            onnx_lat, onnx_sz = benchmark_onnx_cpu(nas_onnx)

        rows.append({
            "model": "Best_NAS_EdgeCNN (CIFAR-10)",
            "parameters": count_parameters(nas_model),
            "pytorch_size_mb": n_prof["model_size_mb"],
            "pytorch_latency_ms": n_prof["latency_ms"],
            "onnx_size_mb": onnx_sz,
            "onnx_latency_ms": onnx_lat,
            "onnx_fps": round(1000.0 / onnx_lat, 1) if onnx_lat else None,
            "peak_ram_mb": n_prof["peak_ram_mb"],
        })

    df = pd.DataFrame(rows)
    out_csv = os.path.join(RESULTS_DIR, "edge_benchmark_results.csv")
    df.to_csv(out_csv, index=False)
    print(df.to_string(index=False))
    print(f"\n[SAVED] Benchmark CSV -> {out_csv}")


if __name__ == "__main__":
    run_benchmarks()
