"""
Assignment #04 - Question 1 (Deliverable 1): Train ResNet-50 Teacher on CIFAR-100
Student: Inamul Haq | Roll No: i22-1906
"""

import os
import sys
import time
import torch
import torch.nn as nn
import torch.optim as optim

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import DEVICE, Q1_CONFIG, CKPT_DIR
from utils import set_seed, get_cifar100_loaders, evaluate_accuracy, count_parameters
from q1_kd.models import ResNet50Teacher


def train_teacher():
    set_seed(42)
    print("=" * 70)
    print("Training ResNet-50 Teacher Network on CIFAR-100")
    print(f"Device: {DEVICE} | Epochs: {Q1_CONFIG['teacher_epochs']}")
    print("=" * 70)

    train_loader, test_loader = get_cifar100_loaders(
        batch_size=Q1_CONFIG["batch_size"],
        num_workers=Q1_CONFIG["num_workers"],
    )

    teacher = ResNet50Teacher(num_classes=Q1_CONFIG["num_classes"]).to(DEVICE)
    print(f"Teacher Trainable Parameters: {count_parameters(teacher):,}")

    criterion = nn.CrossEntropyLoss(label_smoothing=0.1)
    optimizer = optim.SGD(
        teacher.parameters(),
        lr=Q1_CONFIG["lr"],
        momentum=0.9,
        weight_decay=Q1_CONFIG["weight_decay"],
    )
    scheduler = optim.lr_scheduler.CosineAnnealingLR(
        optimizer, T_max=Q1_CONFIG["teacher_epochs"]
    )

    best_acc = 0.0
    save_path = os.path.join(CKPT_DIR, "teacher_resnet50_cifar100.pth")

    for epoch in range(1, Q1_CONFIG["teacher_epochs"] + 1):
        teacher.train()
        t0 = time.time()
        running_loss = 0.0

        for images, labels in train_loader:
            images, labels = images.to(DEVICE), labels.to(DEVICE)
            optimizer.zero_grad()
            logits = teacher(images)
            loss = criterion(logits, labels)
            loss.backward()
            optimizer.step()
            running_loss += loss.item()

        scheduler.step()
        val_acc = evaluate_accuracy(teacher, test_loader, DEVICE)
        elapsed = time.time() - t0
        avg_loss = running_loss / len(train_loader)

        if val_acc >= best_acc:
            best_acc = val_acc
            torch.save(teacher.state_dict(), save_path)

        print(
            f"Epoch [{epoch:02d}/{Q1_CONFIG['teacher_epochs']:02d}] | "
            f"Loss: {avg_loss:.4f} | Val Top-1 Acc: {val_acc:.2f}% | "
            f"Best: {best_acc:.2f}% | Time: {elapsed:.1f}s"
        )

    print(f"\n[DONE] Teacher checkpoint saved to: {save_path} (Best Acc: {best_acc:.2f}%)")


if __name__ == "__main__":
    train_teacher()
