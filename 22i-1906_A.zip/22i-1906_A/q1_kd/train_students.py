"""
Assignment #04 - Question 1 (Deliverables 2, 3, 4, 7):
Trains MobileNetV2, SqueezeNet, and EfficientNet-Lite0 on CIFAR-100:
  Mode A: Baseline training (without Knowledge Distillation)
  Mode B: Knowledge Distillation training (Soft-Target + Hard-Label + Feature Distillation)
  Exports distilled student models to ONNX format.
Student: Inamul Haq | Roll No: i22-1906
"""

import os
import sys
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import DEVICE, Q1_CONFIG, CKPT_DIR, ONNX_DIR, RESULTS_DIR
from utils import (
    set_seed,
    get_cifar100_loaders,
    evaluate_accuracy,
    count_parameters,
    export_model_to_onnx,
)
from q1_kd.models import ResNet50Teacher, build_student
from q1_kd.kd_loss import KnowledgeDistillationLoss, FeatureProjector


def infer_feature_channels(model: nn.Module, device: torch.device) -> list[int]:
    """Dynamically extracts intermediate feature map channel sizes."""
    model.eval()
    with torch.no_grad():
        dummy = torch.randn(2, 3, 32, 32, device=device)
        _, feats = model(dummy, return_features=True)
    return [f.shape[1] for f in feats]


def train_baseline_student(student_name: str, train_loader, test_loader) -> float:
    """Trains a single student model independently from scratch without distillation."""
    set_seed(42)
    print("\n" + "-" * 70)
    print(f"[BASELINE] Training {student_name.upper()} without Knowledge Distillation")
    print("-" * 70)

    student = build_student(student_name, num_classes=Q1_CONFIG["num_classes"]).to(DEVICE)
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.SGD(
        student.parameters(),
        lr=Q1_CONFIG["lr"],
        momentum=0.9,
        weight_decay=Q1_CONFIG["weight_decay"],
    )
    scheduler = optim.lr_scheduler.CosineAnnealingLR(
        optimizer, T_max=Q1_CONFIG["student_epochs"]
    )

    best_acc = 0.0
    save_path = os.path.join(CKPT_DIR, f"baseline_{student_name}_cifar100.pth")

    for epoch in range(1, Q1_CONFIG["student_epochs"] + 1):
        student.train()
        running_loss = 0.0
        for images, labels in train_loader:
            images, labels = images.to(DEVICE), labels.to(DEVICE)
            optimizer.zero_grad()
            logits = student(images)
            loss = criterion(logits, labels)
            loss.backward()
            optimizer.step()
            running_loss += loss.item()

        scheduler.step()
        val_acc = evaluate_accuracy(student, test_loader, DEVICE)
        if val_acc >= best_acc:
            best_acc = val_acc
            torch.save(student.state_dict(), save_path)

        print(
            f"[{student_name} | Baseline] Epoch [{epoch:02d}/{Q1_CONFIG['student_epochs']:02d}] "
            f"| Loss: {running_loss / len(train_loader):.4f} | Val Acc: {val_acc:.2f}% | Best: {best_acc:.2f}%"
        )

    print(f"[SAVED] Baseline checkpoint -> {save_path}")
    return best_acc


def train_distilled_student(
    student_name: str, teacher: nn.Module, teacher_channels: list[int], train_loader, test_loader
) -> float:
    """Trains a student model using combined Soft-Target, Hard-Label, and Feature KD."""
    set_seed(42)
    print("\n" + "-" * 70)
    print(f"[DISTILLED] Training {student_name.upper()} with Multi-Level Knowledge Distillation")
    print("-" * 70)

    student = build_student(student_name, num_classes=Q1_CONFIG["num_classes"]).to(DEVICE)
    student_channels = infer_feature_channels(student, DEVICE)
    projector = FeatureProjector(student_channels, teacher_channels).to(DEVICE)

    kd_criterion = KnowledgeDistillationLoss(
        temperature=Q1_CONFIG["temperature"],
        alpha_ce=Q1_CONFIG["alpha_ce"],
        alpha_kd=Q1_CONFIG["alpha_kd"],
        alpha_feat=Q1_CONFIG["alpha_feat"],
    )

    optimizer = optim.SGD(
        list(student.parameters()) + list(projector.parameters()),
        lr=Q1_CONFIG["lr"],
        momentum=0.9,
        weight_decay=Q1_CONFIG["weight_decay"],
    )
    scheduler = optim.lr_scheduler.CosineAnnealingLR(
        optimizer, T_max=Q1_CONFIG["student_epochs"]
    )

    best_acc = 0.0
    save_path = os.path.join(CKPT_DIR, f"distilled_{student_name}_cifar100.pth")
    teacher.eval()

    for epoch in range(1, Q1_CONFIG["student_epochs"] + 1):
        student.train()
        projector.train()
        running_loss = 0.0

        for images, labels in train_loader:
            images, labels = images.to(DEVICE), labels.to(DEVICE)
            optimizer.zero_grad()

            with torch.no_grad():
                t_logits, t_feats = teacher(images, return_features=True)

            s_logits, s_feats = student(images, return_features=True)
            loss, _ = kd_criterion(
                s_logits, t_logits, labels, s_feats, t_feats, projector
            )
            loss.backward()
            optimizer.step()
            running_loss += loss.item()

        scheduler.step()
        val_acc = evaluate_accuracy(student, test_loader, DEVICE)
        if val_acc >= best_acc:
            best_acc = val_acc
            torch.save(student.state_dict(), save_path)

        print(
            f"[{student_name} | KD] Epoch [{epoch:02d}/{Q1_CONFIG['student_epochs']:02d}] "
            f"| KD Loss: {running_loss / len(train_loader):.4f} | Val Acc: {val_acc:.2f}% | Best: {best_acc:.2f}%"
        )

    print(f"[SAVED] Distilled checkpoint -> {save_path}")

    student.load_state_dict(torch.load(save_path, map_location="cpu"))
    onnx_path = os.path.join(ONNX_DIR, f"distilled_{student_name}.onnx")
    export_model_to_onnx(student, onnx_path, input_shape=(1, 3, 32, 32))
    student.to(DEVICE)

    return best_acc


def main():
    train_loader, test_loader = get_cifar100_loaders(
        batch_size=Q1_CONFIG["batch_size"],
        num_workers=Q1_CONFIG["num_workers"],
    )

    teacher_ckpt = os.path.join(CKPT_DIR, "teacher_resnet50_cifar100.pth")
    if not os.path.exists(teacher_ckpt):
        raise FileNotFoundError(
            f"Teacher checkpoint not found at {teacher_ckpt}. Run q1_kd/train_teacher.py first!"
        )

    teacher = ResNet50Teacher(num_classes=Q1_CONFIG["num_classes"]).to(DEVICE)
    teacher.load_state_dict(torch.load(teacher_ckpt, map_location=DEVICE))
    teacher.eval()
    teacher_acc = evaluate_accuracy(teacher, test_loader, DEVICE)
    teacher_channels = infer_feature_channels(teacher, DEVICE)
    print(f"Loaded Teacher ResNet-50 | Test Accuracy: {teacher_acc:.2f}%")

    records = []
    for student_name in Q1_CONFIG["students"]:
        temp_model = build_student(student_name, Q1_CONFIG["num_classes"])
        params = count_parameters(temp_model)

        base_acc = train_baseline_student(student_name, train_loader, test_loader)
        kd_acc = train_distilled_student(
            student_name, teacher, teacher_channels, train_loader, test_loader
        )

        records.append({
            "student_model": student_name,
            "parameters": params,
            "teacher_acc_pct": round(teacher_acc, 2),
            "baseline_acc_pct": round(base_acc, 2),
            "distilled_acc_pct": round(kd_acc, 2),
            "kd_gain_pct": round(kd_acc - base_acc, 2),
        })

    df = pd.DataFrame(records)
    csv_path = os.path.join(RESULTS_DIR, "q1_training_results.csv")
    df.to_csv(csv_path, index=False)
    print("\n" + "=" * 70)
    print("Question 1 Summary Results:")
    print(df.to_string(index=False))
    print(f"Saved results table -> {csv_path}")


if __name__ == "__main__":
    main()
