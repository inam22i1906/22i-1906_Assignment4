"""
Assignment #04 - Question 1: Knowledge Distillation Loss Module
Student: Inamul Haq | Roll No: i22-1906
Supports:
  1. Hard-label Cross-Entropy loss
  2. Soft-target Temperature-scaled KL-Divergence loss
  3. Intermediate Feature-based Distillation loss (with learnable 1x1 channel adapters)
"""

import torch
import torch.nn as nn
import torch.nn.functional as F


class FeatureProjector(nn.Module):
    """Projects student intermediate feature maps to match teacher channel dimensions."""

    def __init__(self, student_channels: list[int], teacher_channels: list[int]):
        super().__init__()
        self.adapters = nn.ModuleList([
            nn.Sequential(
                nn.Conv2d(s_c, t_c, kernel_size=1, bias=False),
                nn.BatchNorm2d(t_c),
            )
            for s_c, t_c in zip(student_channels, teacher_channels)
        ])

    def forward(self, student_feats: list[torch.Tensor], teacher_feats: list[torch.Tensor]):
        loss = 0.0
        for adapter, s_f, t_f in zip(self.adapters, student_feats, teacher_feats):
            proj_s = adapter(s_f)
            if proj_s.shape[2:] != t_f.shape[2:]:
                proj_s = F.adaptive_avg_pool2d(proj_s, t_f.shape[2:])
            proj_s_norm = F.normalize(proj_s, p=2, dim=1)
            t_f_norm = F.normalize(t_f.detach(), p=2, dim=1)
            loss = loss + F.mse_loss(proj_s_norm, t_f_norm)
        return loss / len(self.adapters)


class KnowledgeDistillationLoss(nn.Module):
    """Combined Hard-Label + Soft-Target (Temperature) + Feature-Based Distillation Loss."""

    def __init__(
        self,
        temperature: float = 4.0,
        alpha_ce: float = 0.3,
        alpha_kd: float = 0.5,
        alpha_feat: float = 0.2,
    ):
        super().__init__()
        self.T = temperature
        self.alpha_ce = alpha_ce
        self.alpha_kd = alpha_kd
        self.alpha_feat = alpha_feat
        self.ce_loss = nn.CrossEntropyLoss()

    def forward(
        self,
        student_logits: torch.Tensor,
        teacher_logits: torch.Tensor,
        targets: torch.Tensor,
        student_feats: list[torch.Tensor] = None,
        teacher_feats: list[torch.Tensor] = None,
        projector: FeatureProjector = None,
    ):
        loss_hard = self.ce_loss(student_logits, targets)

        soft_student = F.log_softmax(student_logits / self.T, dim=1)
        soft_teacher = F.softmax(teacher_logits.detach() / self.T, dim=1)
        loss_soft = F.kl_div(soft_student, soft_teacher, reduction="batchmean") * (self.T ** 2)

        loss_feat = torch.tensor(0.0, device=student_logits.device)
        if (
            self.alpha_feat > 0
            and student_feats is not None
            and teacher_feats is not None
            and projector is not None
        ):
            loss_feat = projector(student_feats, teacher_feats)

        total_loss = (
            self.alpha_ce * loss_hard
            + self.alpha_kd * loss_soft
            + self.alpha_feat * loss_feat
        )
        return total_loss, {
            "hard": loss_hard.item(),
            "soft": loss_soft.item(),
            "feat": loss_feat.item(),
        }
