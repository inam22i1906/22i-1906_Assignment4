"""
Assignment #04 - Question 1 (Deliverables 6, 7):
Unified PyTorch & ONNX Runtime CPU Inference Pipeline for Distilled Student Models.
Student: Inamul Haq | Roll No: i22-1906
"""

import os
import sys
import time
import numpy as np
import torch
import onnxruntime as ort

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import Q1_CONFIG, CKPT_DIR, ONNX_DIR
from utils import get_cifar100_loaders
from q1_kd.models import build_student


class UnifiedStudentInference:
    """Unified inference wrapper supporting PyTorch CPU and ONNX Runtime CPU backends."""

    def __init__(self, student_name: str, backend: str = "onnx"):
        self.student_name = student_name
        self.backend = backend.lower()

        if self.backend == "pytorch":
            ckpt = os.path.join(CKPT_DIR, f"distilled_{student_name}_cifar100.pth")
            self.model = build_student(student_name, Q1_CONFIG["num_classes"]).to("cpu").eval()
            self.model.load_state_dict(torch.load(ckpt, map_location="cpu"))
        elif self.backend == "onnx":
            onnx_path = os.path.join(ONNX_DIR, f"distilled_{student_name}.onnx")
            sess_opts = ort.SessionOptions()
            sess_opts.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
            self.session = ort.InferenceSession(
                onnx_path, sess_options=sess_opts, providers=["CPUExecutionProvider"]
            )
            self.input_name = self.session.get_inputs()[0].name
        else:
            raise ValueError("Backend must be 'pytorch' or 'onnx'")

    def predict(self, input_tensor: np.ndarray) -> np.ndarray:
        """Runs forward pass on batch (N, 3, 32, 32) and returns predicted class indices."""
        if self.backend == "pytorch":
            with torch.no_grad():
                t_in = torch.from_numpy(input_tensor).float()
                logits = self.model(t_in).numpy()
        else:
            logits = self.session.run(None, {self.input_name: input_tensor.astype(np.float32)})[0]
        return np.argmax(logits, axis=1)


def run_unified_inference_demo():
    _, test_loader = get_cifar100_loaders(batch_size=64, num_workers=0)
    sample_images, sample_labels = next(iter(test_loader))
    sample_np = sample_images.numpy()
    labels_np = sample_labels.numpy()

    print("=" * 75)
    print("Unified Student Inference Pipeline (PyTorch CPU vs ONNX Runtime CPU)")
    print("=" * 75)

    for student_name in Q1_CONFIG["students"]:
        for backend in ["pytorch", "onnx"]:
            engine = UnifiedStudentInference(student_name, backend=backend)
            _ = engine.predict(sample_np[:1])

            t0 = time.perf_counter()
            preds = engine.predict(sample_np)
            elapsed_ms = (time.perf_counter() - t0) * 1000.0
            batch_acc = 100.0 * np.mean(preds == labels_np)
            per_img_ms = elapsed_ms / len(sample_np)

            print(
                f"Model: {student_name:<20} | Backend: {backend.upper():<7} | "
                f"Batch Acc: {batch_acc:5.2f}% | Latency/Img: {per_img_ms:6.3f} ms"
            )


if __name__ == "__main__":
    run_unified_inference_demo()
