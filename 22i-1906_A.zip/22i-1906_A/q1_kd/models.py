"""
Assignment #04 - Question 1: Teacher & Student Architectures for CIFAR-100
Student: Inamul Haq | Roll No: i22-1906
Implements:
  - Teacher: CIFAR-adapted ResNet-50
  - Student 1: MobileNetV2 (CIFAR-adapted)
  - Student 2: SqueezeNet 1.1 (CIFAR-adapted)
  - Student 3: EfficientNet-Lite0 (ReLU6-based, no Squeeze-and-Excitation, edge-optimized)
"""

import torch
import torch.nn as nn
import torchvision.models as models


class ResNet50Teacher(nn.Module):
    """ResNet-50 tailored for 32x32 CIFAR-100 with intermediate feature extraction."""

    def __init__(self, num_classes: int = 100):
        super().__init__()
        base = models.resnet50(weights=None)
        base.conv1 = nn.Conv2d(3, 64, kernel_size=3, stride=1, padding=1, bias=False)
        base.maxpool = nn.Identity()
        base.fc = nn.Linear(base.fc.in_features, num_classes)

        self.conv1 = base.conv1
        self.bn1 = base.bn1
        self.relu = base.relu
        self.layer1 = base.layer1
        self.layer2 = base.layer2
        self.layer3 = base.layer3
        self.layer4 = base.layer4
        self.avgpool = base.avgpool
        self.fc = base.fc

    def forward(self, x, return_features: bool = False):
        x = self.relu(self.bn1(self.conv1(x)))
        f1 = self.layer1(x)
        f2 = self.layer2(f1)
        f3 = self.layer3(f2)
        f4 = self.layer4(f3)
        pooled = torch.flatten(self.avgpool(f4), 1)
        logits = self.fc(pooled)
        if return_features:
            return logits, [f2, f3, f4]
        return logits


class MobileNetV2Student(nn.Module):
    """Lightweight MobileNetV2 adapted for 32x32 input with intermediate feature hooks."""

    def __init__(self, num_classes: int = 100, width_mult: float = 1.0):
        super().__init__()
        base = models.mobilenet_v2(weights=None, width_mult=width_mult)
        base.features[0][0].stride = (1, 1)
        in_features = base.classifier[1].in_features
        base.classifier = nn.Sequential(
            nn.Dropout(0.2),
            nn.Linear(in_features, num_classes),
        )
        self.features = base.features
        self.classifier = base.classifier

    def forward(self, x, return_features: bool = False):
        feats = []
        for idx, layer in enumerate(self.features):
            x = layer(x)
            if idx in (6, 13, 18):
                feats.append(x)
        pooled = nn.functional.adaptive_avg_pool2d(x, (1, 1)).flatten(1)
        logits = self.classifier(pooled)
        if return_features:
            return logits, feats
        return logits


class FireModule(nn.Module):
    """SqueezeNet Fire module (1x1 squeeze + parallel 1x1 and 3x3 expand)."""

    def __init__(self, in_channels: int, squeeze_channels: int, expand1x1: int, expand3x3: int):
        super().__init__()
        self.squeeze = nn.Sequential(
            nn.Conv2d(in_channels, squeeze_channels, kernel_size=1),
            nn.BatchNorm2d(squeeze_channels),
            nn.ReLU(inplace=True),
        )
        self.expand1x1 = nn.Sequential(
            nn.Conv2d(squeeze_channels, expand1x1, kernel_size=1),
            nn.BatchNorm2d(expand1x1),
            nn.ReLU(inplace=True),
        )
        self.expand3x3 = nn.Sequential(
            nn.Conv2d(squeeze_channels, expand3x3, kernel_size=3, padding=1),
            nn.BatchNorm2d(expand3x3),
            nn.ReLU(inplace=True),
        )

    def forward(self, x):
        s = self.squeeze(x)
        return torch.cat([self.expand1x1(s), self.expand3x3(s)], dim=1)


class SqueezeNetStudent(nn.Module):
    """SqueezeNet 1.1 student architecture with BatchNorm for stable CIFAR-100 training."""

    def __init__(self, num_classes: int = 100):
        super().__init__()
        self.stage1 = nn.Sequential(
            nn.Conv2d(3, 64, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),
            FireModule(64, 16, 64, 64),
            FireModule(128, 16, 64, 64),
            nn.MaxPool2d(kernel_size=2, stride=2),
        )
        self.stage2 = nn.Sequential(
            FireModule(128, 32, 128, 128),
            FireModule(256, 32, 128, 128),
            nn.MaxPool2d(kernel_size=2, stride=2),
        )
        self.stage3 = nn.Sequential(
            FireModule(256, 48, 192, 192),
            FireModule(384, 48, 192, 192),
            FireModule(384, 64, 256, 256),
            FireModule(512, 64, 256, 256),
        )
        self.classifier = nn.Sequential(
            nn.Dropout(0.3),
            nn.Conv2d(512, num_classes, kernel_size=1),
            nn.ReLU(inplace=True),
            nn.AdaptiveAvgPool2d((1, 1)),
        )

    def forward(self, x, return_features: bool = False):
        f1 = self.stage1(x)
        f2 = self.stage2(f1)
        f3 = self.stage3(f2)
        logits = self.classifier(f3).flatten(1)
        if return_features:
            return logits, [f1, f2, f3]
        return logits


class MBConvLiteBlock(nn.Module):
    """EfficientNet-Lite MBConv block (uses ReLU6 and omits Squeeze-and-Excitation for edge speed)."""

    def __init__(self, in_c: int, out_c: int, expand_ratio: int, kernel_size: int, stride: int):
        super().__init__()
        hidden_c = in_c * expand_ratio
        self.use_res = (stride == 1 and in_c == out_c)
        layers = []
        if expand_ratio != 1:
            layers.extend([
                nn.Conv2d(in_c, hidden_c, 1, bias=False),
                nn.BatchNorm2d(hidden_c),
                nn.ReLU6(inplace=True),
            ])
        layers.extend([
            nn.Conv2d(hidden_c, hidden_c, kernel_size, stride=stride,
                      padding=kernel_size // 2, groups=hidden_c, bias=False),
            nn.BatchNorm2d(hidden_c),
            nn.ReLU6(inplace=True),
            nn.Conv2d(hidden_c, out_c, 1, bias=False),
            nn.BatchNorm2d(out_c),
        ])
        self.block = nn.Sequential(*layers)

    def forward(self, x):
        out = self.block(x)
        return x + out if self.use_res else out


class EfficientNetLite0Student(nn.Module):
    """EfficientNet-Lite0 student architecture tailored for edge deployment & 32x32 inputs."""

    def __init__(self, num_classes: int = 100):
        super().__init__()
        self.stem = nn.Sequential(
            nn.Conv2d(3, 32, kernel_size=3, stride=1, padding=1, bias=False),
            nn.BatchNorm2d(32),
            nn.ReLU6(inplace=True),
        )
        cfg = [
            (1, 16, 1, 1, 3),
            (6, 24, 2, 2, 3),
            (6, 40, 2, 2, 5),
            (6, 80, 3, 2, 3),
            (6, 112, 3, 1, 5),
            (6, 192, 4, 1, 5),
            (6, 320, 1, 1, 3),
        ]
        stages = []
        in_c = 32
        for exp, out_c, n_blocks, stride, k in cfg:
            blocks = []
            for i in range(n_blocks):
                s = stride if i == 0 else 1
                blocks.append(MBConvLiteBlock(in_c, out_c, exp, k, s))
                in_c = out_c
            stages.append(nn.Sequential(*blocks))
        self.stages = nn.ModuleList(stages)

        self.head = nn.Sequential(
            nn.Conv2d(320, 1280, kernel_size=1, bias=False),
            nn.BatchNorm2d(1280),
            nn.ReLU6(inplace=True),
            nn.AdaptiveAvgPool2d((1, 1)),
            nn.Flatten(),
            nn.Dropout(0.2),
            nn.Linear(1280, num_classes),
        )

    def forward(self, x, return_features: bool = False):
        x = self.stem(x)
        feats = []
        for idx, stage in enumerate(self.stages):
            x = stage(x)
            if idx in (2, 4, 6):
                feats.append(x)
        logits = self.head(x)
        if return_features:
            return logits, feats
        return logits


def build_student(name: str, num_classes: int = 100) -> nn.Module:
    name = name.lower()
    if name == "mobilenetv2":
        return MobileNetV2Student(num_classes=num_classes)
    elif name == "squeezenet":
        return SqueezeNetStudent(num_classes=num_classes)
    elif name == "efficientnet_lite0":
        return EfficientNetLite0Student(num_classes=num_classes)
    raise ValueError(f"Unknown student architecture: {name}")
