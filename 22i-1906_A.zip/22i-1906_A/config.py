"""
Assignment #04 - Edge Computing & Intelligent Systems
Student: Inamul Haq | Roll No: i22-1906
Global configuration file for Question 1 (Knowledge Distillation) and Question 2 (Hardware-Aware NAS).
"""

import os
import torch

STUDENT_NAME = "Inamul Haq"
ROLL_NO = "i22-1906"

# Directory setup
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
CKPT_DIR = os.path.join(BASE_DIR, "checkpoints")
ONNX_DIR = os.path.join(BASE_DIR, "onnx_models")
RESULTS_DIR = os.path.join(BASE_DIR, "results")

for d in [DATA_DIR, CKPT_DIR, ONNX_DIR, RESULTS_DIR]:
    os.makedirs(d, exist_ok=True)

# Compute Device
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# Training Hyperparameters (Set FAST_DEMO=False for full multi-epoch runs)
FAST_DEMO = False

Q1_CONFIG = {
    "dataset": "CIFAR-100",
    "num_classes": 100,
    "batch_size": 128,
    "num_workers": 2,
    "teacher_epochs": 3 if FAST_DEMO else 30,
    "student_epochs": 3 if FAST_DEMO else 25,
    "lr": 0.05,
    "weight_decay": 5e-4,
    # Knowledge Distillation hyperparameters
    "temperature": 4.0,
    "alpha_ce": 0.3,       # Hard-label Cross-Entropy weight
    "alpha_kd": 0.5,       # Soft-target KL-Divergence weight
    "alpha_feat": 0.2,     # Intermediate Feature MSE weight
    "students": ["mobilenetv2", "squeezenet", "efficientnet_lite0"],
}

Q2_CONFIG = {
    "dataset": "CIFAR-10",
    "num_classes": 10,
    "batch_size": 128,
    "num_workers": 2,
    "n_trials": 6 if FAST_DEMO else 20,
    "proxy_epochs": 2 if FAST_DEMO else 5,
    "final_epochs": 4 if FAST_DEMO else 25,
    # Hardware deployment constraints for edge devices
    "max_latency_ms": 25.0,       # Maximum allowed CPU inference latency (ms/image)
    "max_model_size_mb": 4.0,     # Maximum allowed storage footprint (MB)
    "max_peak_ram_mb": 150.0,     # Maximum allowed peak inference memory delta (MB)
}
