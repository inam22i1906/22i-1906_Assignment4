"""
Assignment #04 - Deliverable 12: Automated Technical Report & Chart Generator
Student: Inamul Haq | Roll No: i22-1906
Generates charts from experimental CSV logs and builds Technical_Report_i22-1906.pdf.
"""

import os
import json
import pandas as pd
import matplotlib.pyplot as plt
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib import colors

from config import STUDENT_NAME, ROLL_NO, RESULTS_DIR, BASE_DIR


def generate_charts():
    q1_csv = os.path.join(RESULTS_DIR, "q1_training_results.csv")
    bench_csv = os.path.join(RESULTS_DIR, "edge_benchmark_results.csv")
    nas_csv = os.path.join(RESULTS_DIR, "nas_search_history.csv")

    chart_paths = {}

    if os.path.exists(q1_csv):
        df1 = pd.read_csv(q1_csv)
        fig, ax = plt.subplots(figsize=(6.5, 3.6))
        x = range(len(df1))
        ax.bar([i - 0.18 for i in x], df1["baseline_acc_pct"], width=0.35, label="Baseline (No KD)", color="#6c757d")
        ax.bar([i + 0.18 for i in x], df1["distilled_acc_pct"], width=0.35, label="Distilled (Soft + Feat KD)", color="#1f77b4")
        ax.set_xticks(list(x))
        ax.set_xticklabels(df1["student_model"])
        ax.set_ylabel("Top-1 Test Accuracy (%)")
        ax.set_title("CIFAR-100 Student Accuracy: Baseline vs. Knowledge Distillation")
        ax.legend()
        ax.grid(axis="y", linestyle="--", alpha=0.5)
        plt.tight_layout()
        p1 = os.path.join(RESULTS_DIR, "chart_kd_accuracy.png")
        plt.savefig(p1, dpi=200)
        plt.close()
        chart_paths["kd"] = p1

    if os.path.exists(bench_csv):
        dfb = pd.read_csv(bench_csv).dropna(subset=["onnx_latency_ms"])
        fig, ax = plt.subplots(figsize=(6.5, 3.6))
        x = range(len(dfb))
        ax.bar([i - 0.18 for i in x], dfb["pytorch_latency_ms"], width=0.35, label="PyTorch CPU", color="#ff7f0e")
        ax.bar([i + 0.18 for i in x], dfb["onnx_latency_ms"], width=0.35, label="ONNX Runtime CPU", color="#2ca02c")
        ax.set_xticks(list(x))
        ax.set_xticklabels(dfb["model"], rotation=15, ha="right")
        ax.set_ylabel("Mean CPU Latency (ms / image)")
        ax.set_title("Edge Inference Latency: PyTorch CPU vs. ONNX Runtime CPU")
        ax.legend()
        ax.grid(axis="y", linestyle="--", alpha=0.5)
        plt.tight_layout()
        p2 = os.path.join(RESULTS_DIR, "chart_onnx_latency.png")
        plt.savefig(p2, dpi=200)
        plt.close()
        chart_paths["latency"] = p2

    if os.path.exists(nas_csv):
        dfn = pd.read_csv(nas_csv)
        accepted = dfn[dfn["status"] == "ACCEPTED"]
        if not accepted.empty:
            fig, ax = plt.subplots(figsize=(6.5, 3.6))
            sc = ax.scatter(
                accepted["latency_ms"], accepted["val_acc_pct"],
                c=accepted["model_size_mb"], cmap="viridis", s=70, edgecolors="k"
            )
            plt.colorbar(sc, ax=ax, label="Model Size (MB)")
            ax.set_xlabel("CPU Inference Latency (ms)")
            ax.set_ylabel("Validation Accuracy (%)")
            ax.set_title("Hardware-Aware NAS Pareto Exploration (CIFAR-10)")
            ax.grid(True, linestyle="--", alpha=0.5)
            plt.tight_layout()
            p3 = os.path.join(RESULTS_DIR, "chart_nas_tradeoff.png")
            plt.savefig(p3, dpi=200)
            plt.close()
            chart_paths["nas"] = p3

    return chart_paths


def build_pdf():
    charts = generate_charts()
    pdf_path = os.path.join(BASE_DIR, f"Technical_Report_{ROLL_NO}.pdf")
    doc = SimpleDocTemplate(pdf_path, pagesize=letter)
    styles = getSampleStyleSheet()
    story = []

    story.append(Paragraph("<b>Assignment #04: Edge Computing & Intelligent Systems</b>", styles["Title"]))
    story.append(Paragraph(f"<b>Name:</b> {STUDENT_NAME} &nbsp;&nbsp;|&nbsp;&nbsp; <b>Roll No:</b> {ROLL_NO}", styles["Normal"]))
    story.append(Spacer(1, 14))

    story.append(Paragraph("<b>1. Question 1: Multi-Level Knowledge Distillation on CIFAR-100</b>", styles["Heading2"]))
    story.append(Paragraph(
        "A ResNet-50 teacher network adapted for 32x32 resolution was trained on CIFAR-100 and used to distill "
        "knowledge into three lightweight edge students: MobileNetV2, SqueezeNet, and EfficientNet-Lite0. "
        "The distillation objective combines hard-label Cross-Entropy (alpha=0.3), temperature-scaled soft-target "
        "KL-Divergence (T=4.0, alpha=0.5), and normalized intermediate feature alignment via 1x1 convolutional "
        "adapters (alpha=0.2).",
        styles["Normal"]
    ))
    story.append(Spacer(1, 8))

    q1_csv = os.path.join(RESULTS_DIR, "q1_training_results.csv")
    if os.path.exists(q1_csv):
        df1 = pd.read_csv(q1_csv)
        data = [df1.columns.tolist()] + df1.values.tolist()
        t = Table(data)
        t.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1f4e78")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.whitesmoke),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
            ("FONTSIZE", (0, 0), (-1, -1), 8),
        ]))
        story.append(t)
        story.append(Spacer(1, 10))

    if "kd" in charts:
        story.append(Image(charts["kd"], width=440, height=240))
        story.append(Spacer(1, 12))

    story.append(Paragraph("<b>2. Question 2: Hardware-Aware Neural Architecture Search (NAS)</b>", styles["Heading2"]))
    story.append(Paragraph(
        "Using Optuna Bayesian Optimization (TPE Sampler), we searched over variable network depth (3-6 blocks), "
        "channel widths, kernel sizes (3x3 vs. 5x5), block types (Depthwise Separable vs. Standard Conv), "
        "activation functions (ReLU, ReLU6, Hardswish, SiLU), and dynamic input resolutions (24x24, 28x28, 32x32). "
        "Candidate architectures violating CPU latency, storage size, or peak RAM budgets were pruned prior to training.",
        styles["Normal"]
    ))
    story.append(Spacer(1, 8))

    best_json = os.path.join(RESULTS_DIR, "best_nas_architecture.json")
    if os.path.exists(best_json):
        with open(best_json, "r") as f:
            best_info = json.load(f)
        story.append(Paragraph(f"<b>Best Discovered NAS Summary:</b> {json.dumps(best_info['metrics'])}", styles["Normal"]))
        story.append(Spacer(1, 8))

    if "nas" in charts:
        story.append(Image(charts["nas"], width=440, height=240))
        story.append(Spacer(1, 12))

    story.append(Paragraph("<b>3. Edge Deployment & ONNX Runtime CPU Benchmarking</b>", styles["Heading2"]))
    bench_csv = os.path.join(RESULTS_DIR, "edge_benchmark_results.csv")
    if os.path.exists(bench_csv):
        dfb = pd.read_csv(bench_csv)
        data = [dfb.columns.tolist()] + dfb.fillna("-").values.tolist()
        t2 = Table(data)
        t2.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1f4e78")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.whitesmoke),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
            ("FONTSIZE", (0, 0), (-1, -1), 7.5),
        ]))
        story.append(t2)
        story.append(Spacer(1, 10))

    if "latency" in charts:
        story.append(Image(charts["latency"], width=440, height=240))

    doc.build(story)
    print(f"[SAVED] Technical Report PDF -> {pdf_path}")


if __name__ == "__main__":
    build_pdf()
